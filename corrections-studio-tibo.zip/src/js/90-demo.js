/* ---------- Démo : deux patterns + arrangement ---------- */
(function demo(){
  const p1=patterns[0];
  p1.steps[0][0]=3; p1.steps[0][4]=3; p1.steps[0][8]=3; p1.steps[0][12]=3;
  p1.steps[1][4]=3; p1.steps[1][12]=3;
  for(let i=0;i<16;i+=2) p1.steps[2][i]=i%4===0?3:2;
  p1.steps[3][7]=2; p1.steps[3][15]=2;
  [[60,0,2],[63,2,2],[67,4,3],[63,8,2],[60,10,2],[58,12,3],[60,16,4],[55,20,3],[58,24,2],[60,26,5]]
    .forEach(([p,s,d])=>{ if(p1.melo[0]) p1.melo[0].push({pitch:p,start:s,dur:d,vel:0.85}); });
  const p2=newPattern('PAT 2');
  for(let i=0;i<16;i+=2) p2.steps[2][i]=2;
  p2.steps[1][4]=3; p2.steps[1][12]=3; p2.steps[3][14]=3;
  [[63,0,4],[67,4,4],[70,8,4],[67,12,4],[72,16,8],[70,24,4],[67,28,4]]
    .forEach(([p,s,d])=>{ if(p2.melo[0]) p2.melo[0].push({pitch:p,start:s,dur:d,vel:0.8}); });
  patterns.push(p2);
  p1.clips[0]=p1.clips[1]=p1.clips[2]=p1.clips[3]=true;
  p2.clips[2]=p2.clips[3]=true;
  insts[0].send={rev:0.3,dly:0.28};
  addInst('Bass','bass');
  if(insts[1]) insts[1].gain=0.95;
  [[48,0,3],[48,4,3],[51,8,3],[50,12,3]]
    .forEach(([p,s,d])=>{ if(p1.melo[1]){ p1.melo[1].push({pitch:p,start:s,dur:d,vel:0.9}); p1.melo[1].push({pitch:p,start:s+16,dur:d,vel:0.9}); } });
  [[51,0,6],[53,8,6],[48,16,6],[50,24,6]]
    .forEach(([p,s,d])=>{ if(p2.melo[1]) p2.melo[1].push({pitch:p,start:s,dur:d,vel:0.85}); });
  automation.cutoff=[{x:0,v:0.30},{x:2,v:0.55},{x:4,v:1}];
  automation.sdly=[{x:2,v:0.15},{x:4,v:0.45}];
  tracks[1].send.rev=0.22;
  tracks[3].send.rev=0.3;
})();

/* Initialisation — chaque appel est isolé pour ne jamais bloquer window.enterStudio */
try{ selectPattern(0); }catch(e){ console.warn('selectPattern',e); }
try{ selectInst(0); }catch(e){ console.warn('selectInst',e); }
try{ buildPianoRoll(); }catch(e){ console.warn('buildPianoRoll',e); }
try{ renderMixer(); }catch(e){ console.warn('renderMixer',e); }
try{ renderAuto(); }catch(e){ console.warn('renderAuto',e); }
