/* ---------- Écran d'accueil ---------- */
let _entered=false;
function enterStudio(){
  if(_entered) return;
  _entered=true;
  /* Masquage immédiat — ne dépend d'aucune transition */
  const _sp=document.getElementById('splash');
  if(_sp){ _sp.classList.add('hide'); _sp.style.cssText+='display:none!important'; }
  try{ audio(); }catch(e){}
  try{ initMidi(); }catch(e){}
  try{ applyPendingTibo(); }catch(e){}
  if(window._resume){
    try{
      applyProject(window._resume);
      setStatus('Session précédente restaurée — réglages, patterns et notes. (Les samples audio ne sont pas dans l\'autosauvegarde : sauvegardez en .tibo pour tout conserver.)');
    }catch(e){ try{ setStatus('Reprise impossible : '+e); }catch(e2){} }
    window._resume=null;
  }
  if(_sp){ setTimeout(()=>{ try{_sp.remove();}catch(e){} },100); }
  try{ setStatus(isTauri?'Bienvenue dans STUDIO TIBO — bonne production !':'Bienvenue dans STUDIO TIBO. Appuyez sur espace (ou ▶) pour écouter la démo.'); }catch(e){}
  try{ if(isTauri){ const v=$('.logo .ver'); if(v) v.textContent+=' · app'; } }catch(e){}
}

/* Clavier */
document.addEventListener('keydown',e=>{
  if(e.key==='Enter'&&document.getElementById('splash')&&!document.getElementById('splash').classList.contains('hide')) enterStudio();
});

/* Rendre enterStudio accessible aux attributs onclick/ontouchend du HTML */
window.enterStudio=enterStudio;

/* Listeners JS — une seule entrée garantie par le flag _entered */
(function attachSplashListeners(){
  const se=document.getElementById('splashEnter');
  if(!se) return;
  /* touchend : Android natif, preventDefault supprime le clic synthétique 300 ms */
  se.addEventListener('touchend', function(ev){
    ev.preventDefault();
    enterStudio();
  }, {passive:false});
  /* click : souris bureau et navigateur web */
  se.addEventListener('click', enterStudio);
  /* Sécurité : le div parent reçoit aussi touchend au cas où le bouton serait raté */
  const sp=document.getElementById('splash');
  if(sp){
    sp.addEventListener('touchend', function(ev){
      if(ev.target===se || se.contains(ev.target)){ ev.preventDefault(); enterStudio(); }
    }, {passive:false});
  }
})();
